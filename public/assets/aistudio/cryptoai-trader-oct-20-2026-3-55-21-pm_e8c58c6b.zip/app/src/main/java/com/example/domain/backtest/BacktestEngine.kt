package com.example.domain.backtest

import com.example.data.model.BacktestSummary
import com.example.data.model.BacktestTrade
import com.example.data.model.Candle
import com.example.data.model.EquityPoint
import kotlin.math.max

object BacktestEngine {

    fun runBacktest(
        symbol: String,
        timeframe: String,
        strategyName: String,
        candles: List<Candle>,
        initialCapitalUsd: Double = 10_000.0,
        riskPerTradePercent: Double = 0.5
    ): BacktestSummary {
        if (candles.size < 30) {
            return BacktestSummary(
                strategyName = strategyName,
                symbol = symbol,
                timeframe = timeframe,
                totalTrades = 0,
                winningTrades = 0,
                losingTrades = 0,
                winRatePercent = 0.0,
                profitFactor = 0.0,
                netProfitPercent = 0.0,
                maxDrawdownPercent = 0.0,
                avgTradePercent = 0.0,
                trades = emptyList(),
                equityCurve = listOf(EquityPoint(System.currentTimeMillis(), initialCapitalUsd))
            )
        }

        var currentEquity = initialCapitalUsd
        var peakEquity = initialCapitalUsd
        var maxDrawdown = 0.0
        val trades = mutableListOf<BacktestTrade>()
        val equityCurve = mutableListOf<EquityPoint>()
        equityCurve.add(EquityPoint(candles.first().time, currentEquity))

        var totalGains = 0.0
        var totalLosses = 0.0

        var inTrade: BacktestTrade? = null
        var tradeSl = 0.0
        var tradeTp1 = 0.0
        var tradeTp2 = 0.0
        var tradeTp3 = 0.0

        for (i in 20 until candles.size) {
            val candle = candles[i]
            val prevCandle = candles[i - 1]

            if (inTrade != null) {
                val isLong = inTrade.type == "LONG"
                var exitPrice: Double? = null
                var exitReason: String? = null

                if (isLong) {
                    if (candle.low <= tradeSl) {
                        exitPrice = tradeSl
                        exitReason = "SL"
                    } else if (candle.high >= tradeTp3) {
                        exitPrice = tradeTp3
                        exitReason = "TP3"
                    } else if (candle.high >= tradeTp2) {
                        exitPrice = tradeTp2
                        exitReason = "TP2"
                    } else if (candle.high >= tradeTp1 && i % 4 == 0) {
                        exitPrice = tradeTp1
                        exitReason = "TP1"
                    }
                } else {
                    // Short
                    if (candle.high >= tradeSl) {
                        exitPrice = tradeSl
                        exitReason = "SL"
                    } else if (candle.low <= tradeTp3) {
                        exitPrice = tradeTp3
                        exitReason = "TP3"
                    } else if (candle.low <= tradeTp2) {
                        exitPrice = tradeTp2
                        exitReason = "TP2"
                    } else if (candle.low <= tradeTp1 && i % 4 == 0) {
                        exitPrice = tradeTp1
                        exitReason = "TP1"
                    }
                }

                if (exitPrice != null && exitReason != null) {
                    val pnlPercent = if (isLong) {
                        (exitPrice - inTrade.entryPrice) / inTrade.entryPrice * 100.0
                    } else {
                        (inTrade.entryPrice - exitPrice) / inTrade.entryPrice * 100.0
                    }
                    val riskAmount = currentEquity * (riskPerTradePercent / 100.0)
                    val profitUsd = riskAmount * (pnlPercent / 2.0)
                    currentEquity += profitUsd
                    peakEquity = max(peakEquity, currentEquity)
                    val dd = if (peakEquity > 0) (peakEquity - currentEquity) / peakEquity * 100.0 else 0.0
                    maxDrawdown = max(maxDrawdown, dd)

                    val isWin = profitUsd > 0
                    if (isWin) totalGains += profitUsd else totalLosses += Math.abs(profitUsd)

                    trades.add(
                        inTrade.copy(
                            exitTime = candle.time,
                            exitPrice = exitPrice,
                            exitReason = exitReason,
                            profitPercent = pnlPercent,
                            profitUsd = profitUsd,
                            isWin = isWin
                        )
                    )
                    equityCurve.add(EquityPoint(candle.time, currentEquity))
                    inTrade = null
                }
            } else {
                // Check strategy entry trigger
                // Trend breakout strategy: Higher High + close > EMA 20
                val closes = candles.subList(i - 15, i).map { it.close }
                val ema20 = closes.average()
                val isBullishSignal = candle.close > ema20 && prevCandle.close <= ema20
                val isBearishSignal = candle.close < ema20 && prevCandle.close >= ema20

                if (isBullishSignal) {
                    val entryPrice = candle.close
                    tradeSl = entryPrice * 0.98
                    tradeTp1 = entryPrice * 1.025
                    tradeTp2 = entryPrice * 1.045
                    tradeTp3 = entryPrice * 1.07
                    inTrade = BacktestTrade(
                        id = trades.size + 1,
                        type = "LONG",
                        entryTime = candle.time,
                        entryPrice = entryPrice,
                        exitTime = 0L,
                        exitPrice = 0.0,
                        exitReason = "",
                        profitPercent = 0.0,
                        profitUsd = 0.0,
                        riskReward = 2.4,
                        isWin = false
                    )
                } else if (isBearishSignal && strategyName.contains("فیوچرز")) {
                    val entryPrice = candle.close
                    tradeSl = entryPrice * 1.02
                    tradeTp1 = entryPrice * 0.975
                    tradeTp2 = entryPrice * 0.955
                    tradeTp3 = entryPrice * 0.93
                    inTrade = BacktestTrade(
                        id = trades.size + 1,
                        type = "SHORT",
                        entryTime = candle.time,
                        entryPrice = entryPrice,
                        exitTime = 0L,
                        exitPrice = 0.0,
                        exitReason = "",
                        profitPercent = 0.0,
                        profitUsd = 0.0,
                        riskReward = 2.4,
                        isWin = false
                    )
                }
            }
        }

        val winCount = trades.count { it.isWin }
        val lossCount = trades.count { !it.isWin }
        val winRate = if (trades.isNotEmpty()) (winCount.toDouble() / trades.size * 100.0) else 0.0
        val profitFactor = if (totalLosses > 0) (totalGains / totalLosses) else if (totalGains > 0) 9.99 else 0.0
        val netProfitPercent = ((currentEquity - initialCapitalUsd) / initialCapitalUsd) * 100.0
        val avgTrade = if (trades.isNotEmpty()) trades.map { it.profitPercent }.average() else 0.0

        return BacktestSummary(
            strategyName = strategyName,
            symbol = symbol,
            timeframe = timeframe,
            totalTrades = trades.size,
            winningTrades = winCount,
            losingTrades = lossCount,
            winRatePercent = winRate,
            profitFactor = profitFactor,
            netProfitPercent = netProfitPercent,
            maxDrawdownPercent = maxDrawdown,
            avgTradePercent = avgTrade,
            trades = trades,
            equityCurve = equityCurve
        )
    }
}
