#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Install Gradle 9.3.1 or run .github/workflows/android-build.yml on GitHub." >&2
  exit 127
fi
if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool is required; install a JDK (Java 21)." >&2
  exit 127
fi
if [[ ! -f debug.keystore ]]; then
  keytool -genkeypair -v -keystore debug.keystore -storepass android \
    -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 \
    -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
fi
gradle --no-daemon assembleDebug testDebugUnitTest
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
