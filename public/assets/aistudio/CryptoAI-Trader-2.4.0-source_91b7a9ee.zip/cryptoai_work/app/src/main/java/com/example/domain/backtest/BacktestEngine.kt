package com.example.domain.backtest

import com.example.data.model.BacktestSummary
import com.example.data.model.BacktestTrade
import com.example.data.model.Candle
import com.example.data.model.EquityPoint
import kotlin.math.abs
import kotlin.math.max

/**
 * Deterministic EMA-cross backtest. This is a simplified simulation, not an exchange execution engine.
 * Uses only closed, valid candles, enters at the signal candle close, charges fees/slippage on both sides,
 * and assumes the stop is hit first if stop and target are both inside the same candle.
 */
object BacktestEngine {
    private const val FEE_RATE = 0.0005       // 0.05% per side, configurable in a future settings UI
    private const val SLIPPAGE_RATE = 0.0005  // 0.05% per side conservative simulation
    private const val STOP_DISTANCE_PERCENT = 0.02

    fun runBacktest(
        symbol: String,
        timeframe: String,
        strategyName: String,
        candles: List<Candle>,
        initialCapitalUsd: Double = 10_000.0,
        riskPerTradePercent: Double = 0.5
    ): BacktestSummary {
        val validCandles = candles.filter { c ->
            c.isClosed && c.time > 0 && c.open.isFinite() && c.high.isFinite() &&
                c.low.isFinite() && c.close.isFinite() && c.volume.isFinite() &&
                c.open > 0.0 && c.close > 0.0 && c.low > 0.0 &&
                c.high >= maxOf(c.open, c.close) && c.low <= minOf(c.open, c.close)
        }.sortedBy { it.time }

        if (validCandles.size < 30 || !initialCapitalUsd.isFinite() || initialCapitalUsd <= 0.0 ||
            !riskPerTradePercent.isFinite() || riskPerTradePercent <= 0.0) {
            return emptySummary(symbol, timeframe, strategyName, validCandles, initialCapitalUsd)
        }

        var equity = initialCapitalUsd
        var peakEquity = initialCapitalUsd
        var maxDrawdown = 0.0
        val trades = mutableListOf<BacktestTrade>()
        val equityCurve = mutableListOf(EquityPoint(validCandles.first().time, equity))
        var totalGains = 0.0
        var totalLosses = 0.0
        var openTrade: BacktestTrade? = null
        var stop = 0.0
        var tp1 = 0.0
        var tp2 = 0.0
        var tp3 = 0.0
        var positionNotional = 0.0

        fun closeTrade(trade: BacktestTrade, candle: Candle, rawExit: Double, reason: String) {
            val isLong = trade.type == "LONG"
            // Adverse slippage: lower exit for long, higher exit for short.
            val exitPrice = if (isLong) rawExit * (1.0 - SLIPPAGE_RATE) else rawExit * (1.0 + SLIPPAGE_RATE)
            val grossReturn = if (isLong) {
                (exitPrice - trade.entryPrice) / trade.entryPrice
            } else {
                (trade.entryPrice - exitPrice) / trade.entryPrice
            }
            val exitNotional = positionNotional * (exitPrice / trade.entryPrice)
            val costs = positionNotional * (FEE_RATE + SLIPPAGE_RATE) + exitNotional * FEE_RATE
            val netPnl = positionNotional * grossReturn - costs
            equity += netPnl
            peakEquity = max(peakEquity, equity)
            val drawdown = if (peakEquity > 0.0) (peakEquity - equity) / peakEquity * 100.0 else 0.0
            maxDrawdown = max(maxDrawdown, drawdown)
            if (netPnl > 0.0) totalGains += netPnl else totalLosses += abs(netPnl)
            trades.add(
                trade.copy(
                    exitTime = candle.time,
                    exitPrice = exitPrice,
                    exitReason = reason,
                    profitPercent = if (positionNotional > 0.0) netPnl / positionNotional * 100.0 else 0.0,
                    profitUsd = netPnl,
                    isWin = netPnl > 0.0
                )
            )
            equityCurve.add(EquityPoint(candle.time, equity))
            openTrade = null
            positionNotional = 0.0
        }

        for (i in 20 until validCandles.size) {
            val candle = validCandles[i]
            val previous = validCandles[i - 1]

            val activeTrade = openTrade
            if (activeTrade != null) {
                val isLong = activeTrade.type == "LONG"
                // Conservative ambiguity rule: if stop and any target are touched in one candle, stop first.
                val stopHit = if (isLong) candle.low <= stop else candle.high >= stop
                if (stopHit) {
                    closeTrade(activeTrade, candle, stop, "SL")
                    continue
                }
                val targetHit = when {
                    (if (isLong) candle.high >= tp3 else candle.low <= tp3) -> tp3 to "TP3"
                    (if (isLong) candle.high >= tp2 else candle.low <= tp2) -> tp2 to "TP2"
                    (if (isLong) candle.high >= tp1 else candle.low <= tp1) -> tp1 to "TP1"
                    else -> null
                }
                if (targetHit != null) {
                    closeTrade(activeTrade, candle, targetHit.first, targetHit.second)
                    continue
                }
            } else {
                // EMA approximation uses only candles preceding the current signal candle.
                val priorCloses = validCandles.subList(i - 20, i).map { it.close }
                val emaApprox = priorCloses.average()
                val bullishCross = candle.close > emaApprox && previous.close <= emaApprox
                val bearishCross = candle.close < emaApprox && previous.close >= emaApprox
                val allowShort = strategyName.contains("فیوچرز") || strategyName.contains("Futures", ignoreCase = true)

                val direction = when {
                    bullishCross -> "LONG"
                    bearishCross && allowShort -> "SHORT"
                    else -> null
                }
                if (direction != null) {
                    val entry = candle.close
                    stop = if (direction == "LONG") entry * (1.0 - STOP_DISTANCE_PERCENT) else entry * (1.0 + STOP_DISTANCE_PERCENT)
                    val riskDistance = abs(entry - stop)
                    tp1 = if (direction == "LONG") entry + riskDistance else entry - riskDistance
                    tp2 = if (direction == "LONG") entry + riskDistance * 2.0 else entry - riskDistance * 2.0
                    tp3 = if (direction == "LONG") entry + riskDistance * 3.0 else entry - riskDistance * 3.0
                    val riskBudget = equity * riskPerTradePercent / 100.0
                    positionNotional = if (riskDistance > 0.0) riskBudget / (riskDistance / entry) else 0.0
                    if (positionNotional <= 0.0 || !positionNotional.isFinite()) continue
                    openTrade = BacktestTrade(
                        id = trades.size + 1,
                        type = direction,
                        entryTime = candle.time,
                        entryPrice = entry,
                        exitTime = 0L,
                        exitPrice = 0.0,
                        exitReason = "",
                        profitPercent = 0.0,
                        profitUsd = 0.0,
                        riskReward = 3.0,
                        isWin = false
                    )
                }
            }
        }

        // Close any remaining position at the final available close; no open trade is silently discarded.
        openTrade?.let { trade -> closeTrade(trade, validCandles.last(), validCandles.last().close, "TIMEFRAME_CLOSE") }

        val wins = trades.count { it.isWin }
        val losses = trades.size - wins
        val winRate = if (trades.isNotEmpty()) wins.toDouble() / trades.size * 100.0 else 0.0
        val profitFactor = when {
            totalLosses > 0.0 -> totalGains / totalLosses
            totalGains > 0.0 -> 99.0
            else -> 0.0
        }
        return BacktestSummary(
            strategyName = strategyName,
            symbol = symbol,
            timeframe = timeframe,
            totalTrades = trades.size,
            winningTrades = wins,
            losingTrades = losses,
            winRatePercent = winRate,
            profitFactor = profitFactor,
            netProfitPercent = (equity - initialCapitalUsd) / initialCapitalUsd * 100.0,
            maxDrawdownPercent = maxDrawdown,
            avgTradePercent = if (trades.isNotEmpty()) trades.map { it.profitPercent }.average() else 0.0,
            trades = trades,
            equityCurve = equityCurve
        )
    }

    private fun emptySummary(
        symbol: String,
        timeframe: String,
        strategyName: String,
        candles: List<Candle>,
        initialCapitalUsd: Double
    ) = BacktestSummary(
        strategyName = strategyName,
        symbol = symbol,
        timeframe = timeframe,
        totalTrades = 0,
        winningTrades = 0,
        losingTrades = 0,
        winRatePercent = 0.0,
        profitFactor = 0.0,
        netProfitPercent = 0.0,
        maxDrawdownPercent = 0.0,
        avgTradePercent = 0.0,
        trades = emptyList(),
        equityCurve = listOf(EquityPoint(candles.firstOrNull()?.time ?: System.currentTimeMillis(), initialCapitalUsd))
    )
}
