package com.example.data.repository

import com.example.data.model.MarginType
import com.example.data.model.MarketType
import com.example.data.model.PaperAccount
import com.example.data.model.PaperPosition
import com.example.data.model.PaperTradeRecord
import com.example.data.model.RiskSettings
import com.example.data.model.TradeSignal
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

class PaperTradingRepository {

    private val _account = MutableStateFlow(PaperAccount())
    val account = _account.asStateFlow()

    private val _openPositions = MutableStateFlow<List<PaperPosition>>(emptyList())
    val openPositions = _openPositions.asStateFlow()

    private val _tradeHistory = MutableStateFlow<List<PaperTradeRecord>>(emptyList())
    val tradeHistory = _tradeHistory.asStateFlow()

    fun resetAccount(initialBalance: Double = 10_000.0) {
        _account.value = PaperAccount(
            initialBalanceUsd = initialBalance,
            availableBalanceUsd = initialBalance,
            totalEquityUsd = initialBalance,
            realizedPnLUsd = 0.0,
            unrealizedPnLUsd = 0.0,
            maxDrawdownPercent = 0.0,
            winRatePercent = 0.0,
            totalTradesCount = 0,
            winningTradesCount = 0,
            losingTradesCount = 0
        )
        _openPositions.value = emptyList()
        _tradeHistory.value = emptyList()
    }

    fun openPosition(
        symbol: String,
        marketType: MarketType,
        direction: String, // "LONG" or "SHORT" or "SPOT_BUY"
        entryPrice: Double,
        amount: Double,
        leverage: Int = 1,
        marginType: MarginType = MarginType.ISOLATED,
        stopLoss: Double? = null,
        tp1: Double? = null,
        tp2: Double? = null,
        tp3: Double? = null
    ): Result<PaperPosition> {
        val notionalValue = entryPrice * amount
        val requiredMargin = if (marketType == MarketType.FUTURES_USDT_M) {
            notionalValue / leverage
        } else {
            notionalValue
        }

        val fee = notionalValue * 0.0005 // 0.05% fee

        if (_account.value.availableBalanceUsd < (requiredMargin + fee)) {
            return Result.failure(Exception("موجودی حساب آزمایشی برای این سفارش کافی نیست. مارجین موردنیاز: $${String.format(java.util.Locale.US, "%.2f", requiredMargin)}"))
        }

        // Calculate liquidation price for Futures
        var liqPrice: Double? = null
        if (marketType == MarketType.FUTURES_USDT_M && leverage > 1) {
            val mmr = 0.005
            liqPrice = if (direction == "LONG") {
                entryPrice * (1.0 - (1.0 / leverage) + mmr)
            } else {
                entryPrice * (1.0 + (1.0 / leverage) - mmr)
            }
        }

        val newPosition = PaperPosition(
            id = UUID.randomUUID().toString(),
            symbol = symbol,
            marketType = marketType,
            direction = direction,
            entryPrice = entryPrice,
            currentPrice = entryPrice,
            amount = amount,
            notionalValueUsd = notionalValue,
            leverage = leverage,
            marginType = marginType,
            marginUsd = requiredMargin,
            stopLoss = stopLoss,
            takeProfit1 = tp1,
            takeProfit2 = tp2,
            takeProfit3 = tp3,
            liquidationPrice = liqPrice,
            unrealizedPnLUsd = -fee,
            pnlPercent = -(fee / requiredMargin) * 100.0,
            openTime = System.currentTimeMillis()
        )

        // Deduct margin + fee
        val curAccount = _account.value
        _account.value = curAccount.copy(
            availableBalanceUsd = curAccount.availableBalanceUsd - requiredMargin - fee,
            totalEquityUsd = curAccount.totalEquityUsd - fee
        )

        _openPositions.value = _openPositions.value + newPosition
        return Result.success(newPosition)
    }

    // Direct 1-Click transfer from TradeSignal to Paper Trading!
    fun openFromSignal(signal: TradeSignal, accountBalanceFraction: Double = 0.2): Result<PaperPosition> {
        val entry = signal.entryPrice
        val amount = if (signal.suggestedPositionSizeUsd > 0) {
            signal.suggestedPositionSizeUsd / entry
        } else {
            (_account.value.availableBalanceUsd * accountBalanceFraction) / entry
        }

        val direction = if (signal.marketType == MarketType.SPOT) {
            "SPOT_BUY"
        } else if (signal.isLong) {
            "LONG"
        } else {
            "SHORT"
        }

        return openPosition(
            symbol = signal.symbol,
            marketType = signal.marketType,
            direction = direction,
            entryPrice = entry,
            amount = amount,
            leverage = if (signal.marketType == MarketType.FUTURES_USDT_M) signal.recommendedLeverage else 1,
            marginType = MarginType.ISOLATED,
            stopLoss = signal.stopLoss,
            tp1 = signal.takeProfit1,
            tp2 = signal.takeProfit2,
            tp3 = signal.takeProfit3
        )
    }

    fun closePosition(positionId: String, exitPrice: Double, exitReason: String = "دستی"): Boolean {
        val pos = _openPositions.value.find { it.id == positionId } ?: return false
        val isLong = pos.direction == "LONG" || pos.direction == "SPOT_BUY"

        val pnlUsd = if (isLong) {
            pos.amount * (exitPrice - pos.entryPrice)
        } else {
            pos.amount * (pos.entryPrice - exitPrice)
        }

        val closeFee = (exitPrice * pos.amount) * 0.0005
        val netPnl = pnlUsd - closeFee
        val pnlPercent = (netPnl / pos.marginUsd) * 100.0

        val tradeRecord = PaperTradeRecord(
            id = UUID.randomUUID().toString(),
            symbol = pos.symbol,
            marketType = pos.marketType,
            direction = pos.direction,
            entryPrice = pos.entryPrice,
            exitPrice = exitPrice,
            exitReason = exitReason,
            amount = pos.amount,
            pnlUsd = netPnl,
            pnlPercent = pnlPercent,
            feeUsd = closeFee,
            openTime = pos.openTime,
            closeTime = System.currentTimeMillis(),
            isWin = netPnl > 0
        )

        // Return margin + netPnL to account
        val curAcc = _account.value
        val newAvailable = curAcc.availableBalanceUsd + pos.marginUsd + netPnl
        val newRealized = curAcc.realizedPnLUsd + netPnl
        val newTrades = _tradeHistory.value + tradeRecord
        val winCount = newTrades.count { it.isWin }
        val winRate = (winCount.toDouble() / newTrades.size) * 100.0

        _openPositions.value = _openPositions.value.filter { it.id != positionId }
        _tradeHistory.value = newTrades

        _account.value = curAcc.copy(
            availableBalanceUsd = max(0.0, newAvailable),
            realizedPnLUsd = newRealized,
            totalTradesCount = newTrades.size,
            winningTradesCount = winCount,
            losingTradesCount = newTrades.size - winCount,
            winRatePercent = winRate
        )

        recalculateAccountEquity()
        return true
    }

    fun updateLivePrices(priceMap: Map<String, Double>) {
        if (_openPositions.value.isEmpty()) return
        val updated = _openPositions.value.toMutableList()
        var positionsClosed = false

        for (i in updated.indices) {
            val pos = updated[i]
            val livePrice = priceMap[pos.symbol] ?: continue
            val isLong = pos.direction == "LONG" || pos.direction == "SPOT_BUY"

            // Check auto TP / SL triggers
            if (isLong) {
                if (pos.stopLoss != null && livePrice <= pos.stopLoss) {
                    closePosition(pos.id, pos.stopLoss, "حد ضرر (SL)")
                    positionsClosed = true
                    continue
                }
                if (pos.takeProfit3 != null && livePrice >= pos.takeProfit3) {
                    closePosition(pos.id, pos.takeProfit3, "هدف سوم (TP3)")
                    positionsClosed = true
                    continue
                }
            } else {
                // Short
                if (pos.stopLoss != null && livePrice >= pos.stopLoss) {
                    closePosition(pos.id, pos.stopLoss, "حد ضرر (SL)")
                    positionsClosed = true
                    continue
                }
                if (pos.takeProfit3 != null && livePrice <= pos.takeProfit3) {
                    closePosition(pos.id, pos.takeProfit3, "هدف سوم (TP3)")
                    positionsClosed = true
                    continue
                }
            }

            // Normal update PnL
            val pnl = if (isLong) {
                pos.amount * (livePrice - pos.entryPrice)
            } else {
                pos.amount * (pos.entryPrice - livePrice)
            }
            val pnlPct = if (pos.marginUsd > 0) (pnl / pos.marginUsd) * 100.0 else 0.0

            updated[i] = pos.copy(
                currentPrice = livePrice,
                unrealizedPnLUsd = pnl,
                pnlPercent = pnlPct
            )
        }

        if (!positionsClosed) {
            _openPositions.value = updated
            recalculateAccountEquity()
        }
    }

    private fun recalculateAccountEquity() {
        val totalUnrealized = _openPositions.value.sumOf { it.unrealizedPnLUsd }
        val lockedMargin = _openPositions.value.sumOf { it.marginUsd }
        val acc = _account.value
        val equity = acc.availableBalanceUsd + lockedMargin + totalUnrealized

        val peak = max(acc.initialBalanceUsd, equity)
        val drawdown = if (peak > 0) ((peak - equity) / peak) * 100.0 else 0.0

        _account.value = acc.copy(
            totalEquityUsd = equity,
            unrealizedPnLUsd = totalUnrealized,
            maxDrawdownPercent = max(acc.maxDrawdownPercent, drawdown)
        )
    }
}
