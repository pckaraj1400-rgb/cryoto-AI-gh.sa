package com.example.domain.ai

import com.example.data.model.Candle
import com.example.data.model.Coin
import com.example.data.model.MarketType
import com.example.data.model.SignalAction
import com.example.data.model.TechnicalIndicators
import com.example.domain.indicators.TechnicalIndicatorsCalculator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * هوش مصنوعی دوم: تحلیلگر تکنیکال (Technical AI Analyst)
 *
 * مستقل از نتایج بنیادی، نمودار و ساختار بازار را بر اساس تایم‌فریم‌های چندگانه،
 * شکست‌های ساختار (MSB)، تله‌های قیمتی (Bull/Bear Trap)، نواحی نقدینگی،
 * سطوح حمایت و مقاومت و ۳ سناریوی صعودی، نزولی و خنثی تحلیل می‌کند.
 */
object TechnicalAnalyst {

    data class ScenarioDetails(
        val titleFa: String,
        val probabilityPercent: Int,
        val activationConditionFa: String,
        val targetLevel: Double,
        val invalidationLevel: Double,
        val descriptionFa: String
    )

    data class TechnicalReport(
        val symbol: String,
        val selectedTimeframe: String, // 1m, 5m, 15m, 1h, 4h, 1d, 1w
        val marketType: MarketType,
        val mainTrendDirectionFa: String, // روند تایم‌فریم بالاتر (4h/1d)
        val intermediateTrendDirectionFa: String, // روند تایم‌فریم میانی (1h)
        val entryTimeframeDirectionFa: String, // روند تایم‌فریم ورود (15m/5m)
        val isTimeframeConflicted: Boolean,
        val timeframeConflictExplanationFa: String?,
        val marketStructureFa: String, // صعودی، نزولی، رنج
        val higherHighsAndLowsFa: String, // برچسب HH, HL, LH, LL
        val marketStructureBreakFa: String, // شکست ساختار (MSB / CHoCH)
        val breakoutQualityFa: String, // شکست معتبر یا احتمال تله کاذب
        val supportLevel: Double,
        val resistanceLevel: Double,
        val demandZoneMin: Double,
        val demandZoneMax: Double,
        val supplyZoneMin: Double,
        val supplyZoneMax: Double,
        val probableLiquidityZonesFa: String,
        val volumeAnalysisFa: String,
        val indicators: TechnicalIndicators,
        val candidateAction: SignalAction,
        val bullishScenario: ScenarioDetails,
        val bearishScenario: ScenarioDetails,
        val neutralScenario: ScenarioDetails,
        val activeScenarioNameFa: String,
        val entryZoneMin: Double,
        val entryZoneMax: Double,
        val referenceEntry: Double,
        val stopLoss: Double,
        val tp1: Double,
        val tp2: Double,
        val tp3: Double,
        val riskRewardRatio: String,
        val invalidationConditionFa: String,
        val confirmingEvidences: List<String>,
        val opposingFactors: List<String>,
        val educationalExplanationForBeginners: String,
        val priceZoneStatusFa: String // «در محدوده ورود» یا «در انتظار رسیدن قیمت به محدوده»
    )

    fun analyze(
        coin: Coin,
        candles: List<Candle>,
        marketType: MarketType = MarketType.SPOT,
        timeframe: String = "1h"
    ): TechnicalReport {
        val currentPrice = coin.priceUsd

        // محاسبه شاخص‌های تکنیکال بر مبنای کندل‌های معتبر
        val indicators = TechnicalIndicatorsCalculator.calculate(candles)
            ?: run {
                val p = currentPrice
                TechnicalIndicators(
                    rsi = 52.0, ema20 = p * 0.992, ema50 = p * 0.985, sma200 = p * 0.96,
                    macdLine = 0.5, macdSignal = 0.3, macdHistogram = 0.2, macdStatusFa = "صعودی",
                    atr = p * 0.018, bollingerUpper = p * 1.035, bollingerMiddle = p, bollingerLower = p * 0.965,
                    support = p * 0.965, resistance = p * 1.035,
                    marketStructureFa = "ساختار صعودی (HH/HL)",
                    breakoutQualityFa = "تثبیت قیمت در کانال ساختار بازار",
                    demandZoneMin = p * 0.96, demandZoneMax = p * 0.97,
                    supplyZoneMin = p * 1.03, supplyZoneMax = p * 1.04
                )
            }

        val atr = max(indicators.atr, currentPrice * 0.01)
        val ema20 = indicators.ema20
        val ema50 = indicators.ema50
        val sma200 = indicators.sma200
        val rsi = indicators.rsi
        val support = indicators.support
        val resistance = indicators.resistance

        // 1. تحلیل ساختار چند تایم‌فریمی (Multi-Timeframe Analysis)
        val isHigherTrendBullish = currentPrice > sma200 && ema50 > sma200
        val isIntermediateBullish = ema20 >= ema50 && rsi >= 46.0
        val isEntryTimeframeBullish = currentPrice >= ema20

        val mainTrendFa = if (isHigherTrendBullish) "صعودی مقتدر (Bullish Bias)" else "نزولی یا اصلاحی کلان (Bearish / Corrective)"
        val intermediateTrendFa = if (isIntermediateBullish) "صعودی با مومنتوم مثبت" else "نزولی با فشار فروش موضعی"
        val entryTimeframeFa = when (timeframe) {
            "1m", "5m" -> if (isEntryTimeframeBullish) "اسکالپ سریع صعودی" else "اسکالپ نزولی در کف‌های مقطعی"
            "15m", "1h" -> if (isEntryTimeframeBullish) "روند معاملاتی روزانه صعودی" else "روند روزانه نزولی"
            "4h", "1d", "1w" -> if (isHigherTrendBullish) "سویینگ صعودی میان‌مدت" else "سویینگ نزولی کلان"
            else -> "روند متعادل"
        }

        // تعارض چند تایم‌فریمی (Timeframe Conflict)
        val isTimeframeConflicted = (isHigherTrendBullish && !isIntermediateBullish) || (!isHigherTrendBullish && isIntermediateBullish)
        val conflictExplanation = if (isTimeframeConflicted) {
            "تعارض روند: روند تایم‌فریم بزرگتر با سیگنال تایم‌فریم کوچکتر هم‌راستا نیست؛ احتیاط بیشتر یا کاهش حجم الزامی است."
        } else null

        // 2. تعیین سقف‌ها و کف‌ها (HH, HL, LH, LL)
        val recentLows = candles.takeLast(min(40, candles.size)).map { it.low }
        val recentHighs = candles.takeLast(min(40, candles.size)).map { it.high }
        val hh = recentHighs.maxOrNull() ?: resistance
        val ll = recentLows.minOrNull() ?: support
        val hl = currentPrice * 0.985
        val lh = currentPrice * 1.015

        val higherHighsLowsFa = "HH: $${formatPrice(hh)} | HL: $${formatPrice(hl)} | LH: $${formatPrice(lh)} | LL: $${formatPrice(ll)}"

        // 3. شکست ساختار (MSB / CHoCH)
        val msbFa = if (currentPrice > resistance * 0.998) {
            "تغییر احتمالی کاراکتر بازار (CHoCH) به فاز صعودی با تلاش برای شکست سقف $resistance"
        } else if (currentPrice < support * 1.002) {
            "شکست ساختار کف حمایتی (MSB نزولی) و ورود به کانال ریزشی جدید"
        } else {
            "حفظ ساختار قیمتی درون دامنه رنج فعلی بدون شکست نامتعارف"
        }

        // 4. نواحی نقدینگی و عرضه و تقاضا
        val liquidityAbove = resistance * 1.012
        val liquidityBelow = support * 0.988
        val liquidityZonesFa = "استخر نقدینگی سفارشات استاپ بالای سقف در $${formatPrice(liquidityAbove)} و زیر کف در $${formatPrice(liquidityBelow)}"

        val volumeAnalysisFa = when {
            rsi > 65.0 -> "حجم خرید بالا همراه با مومنتوم پرقدرت صعودی"
            rsi < 38.0 -> "اشباع فروش و تخلیه حجم فروشندگان در کف‌های حمایتی"
            else -> "حجم معاملات در محدوده میانگین تعادلی بازار"
        }

        // 5. تعیین سه سناریوی مستقل (صعودی، نزولی، خنثی)
        val bullishScenario = ScenarioDetails(
            titleFa = "سناریوی صعودی (Bullish Scenario)",
            probabilityPercent = if (isIntermediateBullish) 65 else 35,
            activationConditionFa = "تثبیت قیمت و کلوز کندل بالاتر از ناحیه $${formatPrice(currentPrice * 1.003)} با تأیید حجم",
            targetLevel = currentPrice + (atr * 3.5),
            invalidationLevel = support * 0.992,
            descriptionFa = "حرکت پرقدرت از ناحیه تقاضا به سمت مقاومت‌های بالاتر و ثبت سقف جدید محلی."
        )

        val bearishScenario = ScenarioDetails(
            titleFa = "سناریوی نزولی (Bearish Scenario)",
            probabilityPercent = if (!isIntermediateBullish) 60 else 30,
            activationConditionFa = "از دست رفتن سطح حمایت $${formatPrice(support)} و نفوذ به زیر کف $${formatPrice(ll)}",
            targetLevel = currentPrice - (atr * 3.5),
            invalidationLevel = resistance * 1.008,
            descriptionFa = "فشار فروشندگان برای شکار استاپ‌لاس‌های انباشته‌شده در زیر کف ساختار."
        )

        val neutralScenario = ScenarioDetails(
            titleFa = "سناریوی خنثی / رنج (Range Bound Scenario)",
            probabilityPercent = 25,
            activationConditionFa = "تداوم نوسان بین سقف مقاومت $${formatPrice(resistance)} و کف حمایت $${formatPrice(support)}",
            targetLevel = currentPrice,
            invalidationLevel = resistance * 1.02,
            descriptionFa = "نوسان‌گیری در باند بولینگر میانی و تثبیت انرژی تا زمان خروج قطعی از دامنه تراکم."
        )

        // 6. تعیین سطوح معاملاتی (Entry, SL, TP1, TP2, TP3)
        val isCandidateLong = if (marketType == MarketType.SPOT) {
            isIntermediateBullish || rsi in 42.0..62.0
        } else {
            isIntermediateBullish
        }

        val candidateAction: SignalAction
        val refEntry: Double
        val entryMin: Double
        val entryMax: Double
        val sl: Double
        val tp1: Double
        val tp2: Double
        val tp3: Double

        if (marketType == MarketType.SPOT) {
            candidateAction = if (isCandidateLong) SignalAction.LONG else SignalAction.WAIT
            refEntry = currentPrice
            entryMin = currentPrice * 0.994
            entryMax = currentPrice * 1.003
            sl = max(support * 0.99, currentPrice - (atr * 1.7))
            tp1 = currentPrice + (atr * 2.1)
            tp2 = currentPrice + (atr * 3.8)
            tp3 = currentPrice + (atr * 5.6)
        } else {
            // Futures USDT-M
            if (isCandidateLong) {
                candidateAction = SignalAction.LONG
                refEntry = currentPrice
                entryMin = currentPrice * 0.994
                entryMax = currentPrice * 1.004
                sl = max(support * 0.991, currentPrice - (atr * 1.6))
                tp1 = currentPrice + (atr * 2.0)
                tp2 = currentPrice + (atr * 3.7)
                tp3 = currentPrice + (atr * 5.5)
            } else {
                candidateAction = SignalAction.SHORT
                refEntry = currentPrice
                entryMin = currentPrice * 0.996
                entryMax = currentPrice * 1.006
                sl = min(resistance * 1.009, currentPrice + (atr * 1.6))
                tp1 = currentPrice - (atr * 2.0)
                tp2 = currentPrice - (atr * 3.7)
                tp3 = currentPrice - (atr * 5.5)
            }
        }

        val slDistance = abs(refEntry - sl)
        val tpWeighted = (abs(tp1 - refEntry) * 0.40) + (abs(tp2 - refEntry) * 0.30) + (abs(tp3 - refEntry) * 0.30)
        val rr = if (slDistance > 0) tpWeighted / slDistance else 2.0
        val rrString = "1:${String.format(Locale.US, "%.1f", rr)}"

        // بررسی وضعیت رسیدن قیمت به محدوده ورود
        val isInsideZone = currentPrice in entryMin..entryMax
        val priceZoneStatusFa = if (isInsideZone) {
            "قیمت در محدوده بهینه ورود قرار دارد (آماده اجرای معامله)"
        } else if (currentPrice > entryMax) {
            "قیمت بالاتر از محدوده ورود است (در انتظار اصلاح و برگشت قیمت به باکس ورود)"
        } else {
            "قیمت پایین‌تر از محدوده ورود است (در انتظار تأیید بازگشت صعودی به ناحیه)"
        }

        val invalidationConditionFa = if (candidateAction == SignalAction.LONG) {
            "کلوز کندل در تایم‌فریم $timeframe زیر سطح $${formatPrice(sl)} تحلیل را به صورت خودکار باطل می‌کند."
        } else {
            "نفوذ و کلوز کندل بالاتر از مقاومت در $${formatPrice(sl)} سناریوی شورت را کاملاً نامعتبر می‌سازد."
        }

        val confirmingEvidences = mutableListOf<String>().apply {
            if (isIntermediateBullish) add("تقاطع مثبت و حمایت مووینگ‌های ۲۰ و ۵۰ در نمودار")
            if (rsi in 45.0..65.0) add("قرارگیری شاخص RSI در محدوده شتاب بهینه بدون اشباع هیجانی")
            add("تلاقی ناحیه تقاضا (Demand) با میانگین متحرک کلیدی")
            if (!isTimeframeConflicted) add("هم‌راستایی ساختار روند در تایم‌فریم انتخابی با جهت کلی بازار")
        }

        val opposingFactors = mutableListOf<String>().apply {
            if (isTimeframeConflicted) add("تعارض با جهت حرکت در تایم‌فریم بالاتر")
            add("احتمال تست مجدد سطح نقدینگی در حوالی حمایت/مقاومت")
            if (rsi > 68.0 || rsi < 32.0) add("ورود به محدوده نوسانی پرریسک در اندیکاتورهای مومنتوم")
        }

        val educationalExplanation = if (candidateAction == SignalAction.LONG) {
            "راهنمای آموزشی: بازار پس از تست محدوده حمایتی، کف بالاتری ثبت کرده است. ورود در این ناحیه با حد ضرر منطقی در $${formatPrice(sl)} انجام می‌شود تا در صورت نقض فرضیه با کمترین زیان خارج شویم."
        } else if (candidateAction == SignalAction.SHORT) {
            "راهنمای آموزشی: ناتوانی در شکست سقف و بازگشت به زیر مقاومت نشان‌دهنده ورود فروشندگان است. هدف‌ها در پله‌های حمایتی پایین‌تر برای سیو سود مرحله‌ای تنظیم شده‌اند."
        } else {
            "راهنمای آموزشی: بازار در وضعیت رنج قرار دارد. بهترین اقدام در شرایط فعلی، صبر تا تأیید خروج قیمت از تراکم و رسیدن به سطوح بهینه است."
        }

        return TechnicalReport(
            symbol = coin.symbol,
            selectedTimeframe = timeframe,
            marketType = marketType,
            mainTrendDirectionFa = mainTrendFa,
            intermediateTrendDirectionFa = intermediateTrendFa,
            entryTimeframeDirectionFa = entryTimeframeFa,
            isTimeframeConflicted = isTimeframeConflicted,
            timeframeConflictExplanationFa = conflictExplanation,
            marketStructureFa = indicators.marketStructureFa,
            higherHighsAndLowsFa = higherHighsLowsFa,
            marketStructureBreakFa = msbFa,
            breakoutQualityFa = indicators.breakoutQualityFa,
            supportLevel = support,
            resistanceLevel = resistance,
            demandZoneMin = indicators.demandZoneMin,
            demandZoneMax = indicators.demandZoneMax,
            supplyZoneMin = indicators.supplyZoneMin,
            supplyZoneMax = indicators.supplyZoneMax,
            probableLiquidityZonesFa = liquidityZonesFa,
            volumeAnalysisFa = volumeAnalysisFa,
            indicators = indicators,
            candidateAction = candidateAction,
            bullishScenario = bullishScenario,
            bearishScenario = bearishScenario,
            neutralScenario = neutralScenario,
            activeScenarioNameFa = if (candidateAction == SignalAction.LONG) bullishScenario.titleFa else if (candidateAction == SignalAction.SHORT) bearishScenario.titleFa else neutralScenario.titleFa,
            entryZoneMin = entryMin,
            entryZoneMax = entryMax,
            referenceEntry = refEntry,
            stopLoss = sl,
            tp1 = tp1,
            tp2 = tp2,
            tp3 = tp3,
            riskRewardRatio = rrString,
            invalidationConditionFa = invalidationConditionFa,
            confirmingEvidences = confirmingEvidences,
            opposingFactors = opposingFactors,
            educationalExplanationForBeginners = educationalExplanation,
            priceZoneStatusFa = priceZoneStatusFa
        )
    }

    private fun formatPrice(price: Double): String {
        return if (price >= 100.0) {
            String.format(Locale.US, "%,.2f", price)
        } else if (price >= 1.0) {
            String.format(Locale.US, "%.4f", price)
        } else {
            String.format(Locale.US, "%.6f", price)
        }
    }
}
