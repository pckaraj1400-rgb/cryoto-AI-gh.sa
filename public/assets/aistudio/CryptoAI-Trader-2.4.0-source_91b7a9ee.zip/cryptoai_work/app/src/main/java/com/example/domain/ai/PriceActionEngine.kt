package com.example.domain.ai

import com.example.data.model.Candle
import kotlin.math.abs

/** Rule-based price-action analysis over closed candles only. Scores are evidence scores, not probabilities. */
object PriceActionEngine {
    data class Report(
        val valid: Boolean,
        val marketStructureFa: String,
        val swingHigh: Double,
        val previousSwingHigh: Double,
        val swingLow: Double,
        val previousSwingLow: Double,
        val structureBreakFa: String,
        val candlePatternFa: String,
        val liquiditySweepFa: String,
        val breakoutQualityFa: String,
        val bullishScore: Int,
        val bearishScore: Int,
        val bullishEvidence: Boolean,
        val bearishEvidence: Boolean,
        val notes: List<String>
    )

    fun analyze(input: List<Candle>): Report {
        val candles = input.filter { it.isClosed && validCandle(it) }.sortedBy { it.time }
        if (candles.size < 30) return Report(
            valid = false, marketStructureFa = "داده بسته‌شده کافی نیست", swingHigh = 0.0,
            previousSwingHigh = 0.0, swingLow = 0.0, previousSwingLow = 0.0,
            structureBreakFa = "برای تحلیل ساختار بازار حداقل ۳۰ کندل بسته‌شده لازم است",
            candlePatternFa = "نامشخص", liquiditySweepFa = "نامشخص", breakoutQualityFa = "داده ناکافی",
            bullishScore = 0, bearishScore = 0, bullishEvidence = false, bearishEvidence = false,
            notes = listOf("تحلیل پرایس اکشن به‌دلیل نبود داده کافی انجام نشد")
        )

        val start = maxOf(2, candles.size - 80)
        val highs = mutableListOf<Pair<Int, Double>>()
        val lows = mutableListOf<Pair<Int, Double>>()
        for (i in start until candles.size - 2) {
            val c = candles[i]
            if ((i - 2..i + 2).all { j -> j == i || c.high >= candles[j].high }) highs += i to c.high
            if ((i - 2..i + 2).all { j -> j == i || c.low <= candles[j].low }) lows += i to c.low
        }
        val recentHighs = highs.takeLast(2).map { it.second }
        val recentLows = lows.takeLast(2).map { it.second }
        val swingHigh = recentHighs.lastOrNull() ?: candles.takeLast(30).maxOf { it.high }
        val previousSwingHigh = recentHighs.getOrNull(recentHighs.lastIndex - 1) ?: swingHigh
        val swingLow = recentLows.lastOrNull() ?: candles.takeLast(30).minOf { it.low }
        val previousSwingLow = recentLows.getOrNull(recentLows.lastIndex - 1) ?: swingLow
        val higherHigh = recentHighs.size >= 2 && recentHighs.last() > recentHighs.first()
        val lowerHigh = recentHighs.size >= 2 && recentHighs.last() < recentHighs.first()
        val higherLow = recentLows.size >= 2 && recentLows.last() > recentLows.first()
        val lowerLow = recentLows.size >= 2 && recentLows.last() < recentLows.first()
        val structure = when {
            higherHigh && higherLow -> "ساختار صعودی (HH/HL)"
            lowerHigh && lowerLow -> "ساختار نزولی (LH/LL)"
            else -> "ساختار خنثی یا رنج؛ سقف/کف‌های اخیر هم‌جهت نیستند"
        }

        val last = candles.last()
        val previous = candles[candles.lastIndex - 1]
        val body = abs(last.close - last.open).coerceAtLeast(1e-12)
        val range = (last.high - last.low).coerceAtLeast(1e-12)
        val upperWick = last.high - maxOf(last.open, last.close)
        val lowerWick = minOf(last.open, last.close) - last.low
        val pattern = when {
            previous.close < previous.open && last.close > last.open && last.close >= previous.open && last.open <= previous.close -> "انگالفینگ صعودی"
            previous.close > previous.open && last.close < last.open && last.close <= previous.open && last.open >= previous.close -> "انگالفینگ نزولی"
            body / range <= 0.35 && lowerWick >= body * 2.0 && last.close >= last.low + range * 0.70 -> "پین‌بار صعودی / رد قیمت از کف"
            body / range <= 0.35 && upperWick >= body * 2.0 && last.close <= last.low + range * 0.30 -> "پین‌بار نزولی / رد قیمت از سقف"
            else -> "الگوی کندلی تأییدشده مشخص نیست"
        }
        val bullishPattern = pattern.contains("صعودی")
        val bearishPattern = pattern.contains("نزولی")
        val sweptHigh = last.high > swingHigh && last.close < swingHigh
        val sweptLow = last.low < swingLow && last.close > swingLow
        val sweep = when {
            sweptLow -> "جمع‌آوری احتمالی نقدینگی زیر کف و بسته‌شدن مجدد بالای سطح (Bullish Sweep)"
            sweptHigh -> "جمع‌آوری احتمالی نقدینگی بالای سقف و بسته‌شدن زیر سطح (Bearish Sweep)"
            else -> "شکست نقدینگی واضحی در آخرین کندل بسته‌شده دیده نشد"
        }
        val avgVolume = candles.takeLast(20).map { it.volume }.average()
        val highVolume = avgVolume > 0.0 && last.volume >= avgVolume * 1.3
        val breakout = when {
            last.close > swingHigh && highVolume -> "شکست صعودی با کلوز بالای سقف و حجم بالاتر از میانگین"
            last.close > swingHigh -> "کلوز بالای سقف بدون تأیید قوی حجم؛ نیازمند پولبک/تأیید"
            last.high > swingHigh && last.close <= swingHigh -> "احتمال شکست جعلی صعودی؛ نفوذ به سقف بدون کلوز بالای آن"
            last.close < swingLow && highVolume -> "شکست نزولی با کلوز زیر کف و حجم بالاتر از میانگین"
            last.close < swingLow -> "کلوز زیر کف بدون تأیید قوی حجم؛ نیازمند تأیید"
            last.low < swingLow && last.close >= swingLow -> "احتمال شکست جعلی نزولی؛ نفوذ به کف و برگشت بالای آن"
            else -> "قیمت داخل محدوده سقف و کف اخیر است"
        }
        val bullishBreak = last.close > swingHigh
        val bearishBreak = last.close < swingLow
        val structureBreak = when {
            bullishBreak && lowerHigh && lowerLow -> "CHoCH صعودی احتمالی: کلوز بالای سقف ساختاری در روند نزولی"
            bullishBreak -> "BOS صعودی: کلوز کندل بسته‌شده بالای آخرین سقف نوسانی"
            bearishBreak && higherHigh && higherLow -> "CHoCH نزولی احتمالی: کلوز زیر کف ساختاری در روند صعودی"
            bearishBreak -> "BOS نزولی: کلوز کندل بسته‌شده زیر آخرین کف نوسانی"
            sweptLow -> "احتمال تغییر کوتاه‌مدت پس از sweep کف؛ شکست ساختار هنوز تأیید نشده"
            sweptHigh -> "احتمال تغییر کوتاه‌مدت پس از sweep سقف؛ شکست ساختار هنوز تأیید نشده"
            else -> "BOS/CHoCH تأییدشده‌ای در آخرین کلوز دیده نشد"
        }
        var bull = 0
        var bear = 0
        if (higherHigh && higherLow) bull += 2
        if (lowerHigh && lowerLow) bear += 2
        if (bullishBreak || sweptLow) bull += 2
        if (bearishBreak || sweptHigh) bear += 2
        if (bullishPattern) bull += 1
        if (bearishPattern) bear += 1
        if (highVolume && bullishBreak) bull += 1
        if (highVolume && bearishBreak) bear += 1
        val notes = buildList {
            add("ساختار: $structure")
            add("کندل: $pattern")
            add("نقدینگی: $sweep")
            add("شکست: $breakout")
        }
        return Report(
            valid = true,
            marketStructureFa = structure,
            swingHigh = swingHigh,
            previousSwingHigh = previousSwingHigh,
            swingLow = swingLow,
            previousSwingLow = previousSwingLow,
            structureBreakFa = structureBreak,
            candlePatternFa = pattern,
            liquiditySweepFa = sweep,
            breakoutQualityFa = breakout,
            bullishScore = bull * 12,
            bearishScore = bear * 12,
            bullishEvidence = bullishBreak || sweptLow || bullishPattern || (higherHigh && higherLow),
            bearishEvidence = bearishBreak || sweptHigh || bearishPattern || (lowerHigh && lowerLow),
            notes = notes
        )
    }

    private fun validCandle(c: Candle): Boolean = c.time > 0 && c.open.isFinite() && c.high.isFinite() &&
        c.low.isFinite() && c.close.isFinite() && c.volume.isFinite() && c.open > 0.0 && c.low > 0.0 &&
        c.high >= maxOf(c.open, c.close) && c.low <= minOf(c.open, c.close)
}
