package com.example

import com.example.data.model.Candle
import com.example.data.model.Coin
import com.example.data.model.MarketType
import com.example.data.model.RiskSettings
import com.example.domain.ai.QuantitativeRiskEngine
import com.example.domain.ai.PriceActionEngine
import com.example.domain.indicators.TechnicalIndicatorsCalculator
import com.example.data.repository.PaperTradingRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TradingCalculationsTest {

    @Test
    fun testCurrencyConversions() {
        // 1 USDT = 96,500 Tomans = 965,000 Rials
        val coin = Coin(
            symbol = "BTC",
            name = "Bitcoin",
            nameFa = "بیت‌کوین",
            pair = "BTCUSDT",
            priceUsd = 90_000.0,
            change24h = 2.5,
            high24h = 91_000.0,
            low24h = 89_000.0,
            volume24hUsd = 10_000_000.0,
            usdtRialRate = 965_000.0
        )
        // 1 Toman = 10 Rials
        assertEquals(coin.priceRial, coin.priceToman * 10.0, 0.001)
        assertEquals(86_850_000_000.0, coin.priceRial, 1.0)
        assertEquals(8_685_000_000.0, coin.priceToman, 1.0)
    }

    @Test
    fun testTechnicalIndicatorsMath() {
        val candles = mutableListOf<Candle>()
        val baseTime = System.currentTimeMillis()
        var price = 100.0
        for (i in 0 until 50) {
            price += (if (i % 2 == 0) 1.5 else -0.8)
            candles.add(
                Candle(
                    time = baseTime + (i * 3600_000L),
                    open = price - 0.5,
                    high = price + 1.2,
                    low = price - 1.0,
                    close = price,
                    volume = 1000.0 + (i * 20)
                )
            )
        }

        val indicators = TechnicalIndicatorsCalculator.calculate(candles)
        assertNotNull(indicators)
        indicators?.let {
            assertTrue("RSI should be between 0 and 100", it.rsi in 0.0..100.0)
            assertTrue("EMA20 should be positive", it.ema20 > 0.0)
            assertTrue("EMA50 should be positive", it.ema50 > 0.0)
            assertTrue("Resistance should be >= Support", it.resistance >= it.support)
            assertNotNull(it.marketStructureFa)
            assertNotNull(it.breakoutQualityFa)
        }
    }

    @Test
    fun testRiskEngineRejectsInvalidLongStopLoss() {
        val settings = RiskSettings()
        val result = QuantitativeRiskEngine.evaluate(
            accountBalanceUsd = 10_000.0,
            marketType = MarketType.SPOT,
            isLong = true,
            entryPrice = 100.0,
            stopLoss = 105.0, // Invalid: SL > Entry for LONG
            tp1 = 110.0,
            tp2 = 115.0,
            tp3 = 120.0,
            leverage = 1,
            riskSettings = settings
        )
        assertFalse("Should reject Long trade with SL above Entry", result.isApproved)
    }

    @Test
    fun testRiskEngineValidatesProperRiskReward() {
        val settings = RiskSettings(maxRiskPerTradePercent = 0.5, enforceRiskRewardFilter = true)
        val result = QuantitativeRiskEngine.evaluate(
            accountBalanceUsd = 10_000.0,
            marketType = MarketType.FUTURES_USDT_M,
            isLong = true,
            entryPrice = 100.0,
            stopLoss = 96.0, // 4% SL risk
            tp1 = 108.0, // 8% gain
            tp2 = 114.0, // 14% gain
            tp3 = 122.0, // 22% gain
            leverage = 5,
            riskSettings = settings
        )
        assertTrue("Trade with good R:R and proper SL should be approved", result.isApproved)
        assertEquals(50.0, result.maxRiskAmountUsd, 0.01) // 0.5% of 10,000 = $50
        assertTrue(result.suggestedPositionSizeUsd > 0)
    }

    @Test
    fun testPaperTradingExecutionAndPnL() {
        val repo = PaperTradingRepository()
        repo.resetAccount(10_000.0)

        // Open Long position on ETH
        val openResult = repo.openPosition(
            symbol = "ETH",
            marketType = MarketType.SPOT,
            direction = "LONG",
            entryPrice = 3000.0,
            amount = 1.0, // 1 ETH = $3000
            leverage = 1,
            stopLoss = 2900.0,
            tp1 = 3100.0,
            tp2 = 3200.0,
            tp3 = 3300.0
        )
        assertTrue(openResult.isSuccess)
        assertEquals(1, repo.openPositions.value.size)

        // Close at 3300 (Hit TP3)
        val posId = repo.openPositions.value.first().id
        val closed = repo.closePosition(posId, 3300.0, "TP3")
        assertTrue(closed)
        assertEquals(0, repo.openPositions.value.size)
        assertEquals(1, repo.tradeHistory.value.size)

        val trade = repo.tradeHistory.value.first()
        assertTrue("Trade should be a win", trade.isWin)
        assertTrue("Profit should be around +$300 minus fees", trade.pnlUsd > 290.0)
    }
    @Test
    fun testPaperTradingExecutesPartialTargetsAndChargesEntryFeeOnce() {
        val repo = PaperTradingRepository()
        repo.resetAccount(10_000.0)
        val opened = repo.openPosition(
            symbol = "BTC",
            marketType = MarketType.SPOT,
            direction = "SPOT_BUY",
            entryPrice = 100.0,
            amount = 1.0,
            leverage = 1,
            stopLoss = 90.0,
            tp1 = 110.0,
            tp2 = 120.0,
            tp3 = 130.0
        )
        assertTrue(opened.isSuccess)

        repo.updateLivePrices(mapOf("BTC" to 110.0))
        assertEquals(0.6, repo.openPositions.value.single().amount, 0.000001)
        assertEquals("هدف اول (TP1)", repo.tradeHistory.value.single().exitReason)

        repo.updateLivePrices(mapOf("BTC" to 120.0))
        assertEquals(0.3, repo.openPositions.value.single().amount, 0.000001)
        assertEquals(2, repo.tradeHistory.value.size)

        repo.updateLivePrices(mapOf("BTC" to 130.0))
        assertTrue(repo.openPositions.value.isEmpty())
        assertEquals(3, repo.tradeHistory.value.size)
        assertTrue(repo.tradeHistory.value.all { it.feeUsd > 0.0 })
        assertTrue("Equity should include the entry fee only once", repo.account.value.totalEquityUsd > 10_000.0)
    }

    @Test
    fun testSpotShortIsRejected() {
        val repo = PaperTradingRepository()
        repo.resetAccount(10_000.0)
        val result = repo.openPosition(
            symbol = "BTC",
            marketType = MarketType.SPOT,
            direction = "SHORT",
            entryPrice = 100.0,
            amount = 1.0,
            leverage = 1
        )
        assertFalse(result.isSuccess)
    }

    @Test
    fun testPriceActionRequiresClosedCandles() {
        val insufficient = (0 until 10).map { i ->
            Candle(i + 1L, 100.0, 102.0, 99.0, 101.0, 1000.0, isClosed = true)
        }
        assertFalse(PriceActionEngine.analyze(insufficient).valid)
    }

    @Test
    fun testPriceActionUsesRealSwingLevels() {
        val candles = (0 until 60).map { i ->
            val close = 100.0 + i * 0.15 + kotlin.math.sin(i / 2.0)
            Candle(
                time = i + 1L,
                open = close - 0.1,
                high = close + 0.6,
                low = close - 0.6,
                close = close,
                volume = if (i == 59) 2000.0 else 1000.0,
                isClosed = true
            )
        }
        val report = PriceActionEngine.analyze(candles)
        assertTrue(report.valid)
        assertTrue(report.swingHigh > 0.0)
        assertTrue(report.swingLow > 0.0)
        assertTrue(report.bullishScore >= 0)
        assertTrue(report.bearishScore >= 0)
    }

}
